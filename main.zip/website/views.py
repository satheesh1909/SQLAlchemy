from flask import render_template, Blueprint

views = Blueprint('Views', __name__)

@views.route('/')
def home():
    return render_template("home.html")

